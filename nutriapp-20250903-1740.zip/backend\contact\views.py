import requests
from django.conf import settings
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from django.core.mail import send_mail
from .models import ContactMessage
from .serializers import ContactMessageSerializer
from .throttles import EmailRateThrottle, BurstRateThrottle, SustainedRateThrottle

send_mail(
subject=f"[Contacto] {name}",
message=(
f"Nombre: {name}\nEmail: {email}\nTel: {phone}\n\nMensaje:\n{message}\n"
),
from_email=settings.DEFAULT_FROM_EMAIL,
recipient_list=[settings.NUTRI_CONTACT_TO],
fail_silently=False,
)

VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify'

def verify_recaptcha(token: str, remote_ip: str | None = None) -> bool:
    if not settings.RECAPTCHA_SECRET_KEY:
        return True  # si no hay key, no bloquea (dev)
    if not token:
        return False
    data = {'secret': settings.RECAPTCHA_SECRET_KEY, 'response': token}
    if remote_ip:
        data['remoteip'] = remote_ip
    try:
        r = requests.post(VERIFY_URL, data=data, timeout=5)
        j = r.json()
        return bool(j.get('success')) and float(j.get('score', 0.9)) >= 0.3
    except Exception:
        return False

class ContactCreateView(generics.CreateAPIView):
    queryset = ContactMessage.objects.all()
    serializer_class = ContactMessageSerializer
    permission_classes = [permissions.AllowAny]
    throttle_classes = [EmailRateThrottle, BurstRateThrottle, SustainedRateThrottle]

    def create(self, request, *args, **kwargs):
        ser = self.get_serializer(data=request.data)
        ser.is_valid(raise_exception=True)

        # Captcha opcional
        token = ser.validated_data.get('token', '')
        if not verify_recaptcha(token, request.META.get('REMOTE_ADDR')):
            return Response({'detail': 'CAPTCHA inválido'}, status=status.HTTP_400_BAD_REQUEST)

        # Guardar
        data = {k: v for k, v in ser.validated_data.items() if k not in ('hp', 'token')}
        obj = ContactMessage.objects.create(**data)

        # Email simple (si está configurado)
        subject = 'Nuevo contacto — Sitio Nutrición'
        body = (
            f"Nombre: {obj.name}\nEmail: {obj.email}\nTeléfono: {obj.phone or '-'}\n\nMensaje:\n{obj.message}\n"
        )
        try:
            to = [getattr(settings, 'CONTACT_TO_EMAIL', None) or getattr(settings, 'DEFAULT_FROM_EMAIL', None)]
            to = [x for x in to if x]
            if to:
                send_mail(subject, body, getattr(settings, 'DEFAULT_FROM_EMAIL', 'marce.bizoso9@gmail.com'), to)
        except Exception:
            pass

        headers = self.get_success_headers(ser.data)
        return Response({'ok': True}, status=status.HTTP_201_CREATED, headers=headers)