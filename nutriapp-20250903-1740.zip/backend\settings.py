REST_FRAMEWORK.setdefault('DEFAULT_THROTTLE_RATES', {
    'contact_email': '5/hour',     # por email
    'contact_burst': '5/min',      # por IP (ráfaga)
    'contact_day': '50/day',       # por IP (diario)
})

# Cache para throttling (usar locmem si no tienes otra)
CACHES.setdefault('default', {
    'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
    'LOCATION': 'nutriapp-cache',
})

# reCAPTCHA (opcional)
RECAPTCHA_SECRET_KEY = os.getenv('RECAPTCHA_SECRET_KEY', '')